"use client";

import "./globals.css";
import { CartProvider } from "./context/cartContext";
import { UserProvider } from "./context/UserContext";
import { CategoryProvider } from "./context/CategoryContext";
import Header from "./component/header";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-background text-text">
        <UserProvider>
          <CartProvider>
            <CategoryProvider>
              <Header />
              {children}
            </CategoryProvider>
          </CartProvider>
        </UserProvider>
      </body>
    </html>
  );
}

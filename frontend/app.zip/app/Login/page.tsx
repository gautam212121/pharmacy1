"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const router = useRouter();
//  // backend path required when host the website on server  

  const handleSubmit = async () => {
    try {
      const url = isLogin
        ? "http://localhost:5001/api/auth/login"
        : "http://localhost:5001/api/auth/register";

      const res = await fetch(url, {
        method: "POST",
        body: JSON.stringify({ username, password }),
        headers: { "Content-Type": "application/json" },
      });

      const data = await res.json();

      if (res.ok) {
        if (isLogin) {
          // login success
          localStorage.setItem("username", data.username);
          localStorage.setItem("role", data.role || "user");
          router.push("/"); // redirect to home page
        } else {
          // signup success
          setIsLogin(true);
          setError("✅ Account created! Please login.");
        }
      } else {
        setError(data.message);
      }
    } catch (err) {
      setError("Server not reachable");
    }
  };

  return (
    <div className="flex justify-center">
      <div className="bg-white p-8 rounded shadow-md w-96">
        {/* <h2 className="text-2xl font-bold mb-4">
          {isLogin ? "Login" : "Create Account"}
        </h2> */}

        {error && <p className="text-red-500 mb-2">{error}</p>}

        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          className="w-full mb-2 px-3 py-2 border rounded"
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full mb-4 px-3 py-2 border rounded"
        />

        <button
          onClick={handleSubmit}
          className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600"
        >
          {isLogin ? "Login" : "Sign Up"}
        </button>

        <p
          className="mt-4 text-blue-500 cursor-pointer text-sm text-center"
          onClick={() => {
            setIsLogin(!isLogin);
            setError("");
          }}
        >
          {isLogin
            ? "New here? Create an account"
            : "Already have an account? Login"}
        </p>
      </div>
    </div>
  );
}

"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import axios from "axios";
import { io } from "socket.io-client";
import { useSearchParams } from "next/navigation";
import { useCart } from "../context/cartContext";
import Homeslider from "../home/Homeslider";
import Link from "next/link";
import CheckoutModal from "../component/CheckoutModal";
import RatingStars from "../component/RatingStars";
import { useCategory } from "../context/CategoryContext";



type LabTest = {
  _id: string;
  name: string;
  healthConcern: string;
  price: number;
  image?: string;
  discount?: number;
  rating?: number;
  reviews?: any[];
};

type Product = {
  _id: string;
  title: string;
  description: string;
  image?: string;
  amount?: number;
  discount?: number;
  rating?: number;
  reviews?: any[];
  category?: string;
};

type CartItem = (Product | LabTest) & { qty: number };

export default function Home() {
  const { addToCart } = useCart();
  const { selectedCategory } = useCategory();

  // backend path required when host the website on server  


  const normalizeImage = (img?: string | null) => {
    if (!img) return null;
    if (img.startsWith("http://") || img.startsWith("https://")) return img;
    return `http://localhost:5000${img}`;
  };

  const [products, setProducts] = useState<Product[]>([]);
  const [labTests, setLabTests] = useState<LabTest[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showPopup, setShowPopup] = useState<string | null>(null);
  const [socket, setSocket] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [searchResults, setSearchResults] = useState<{
    products: Product[];
    labTests: LabTest[];
    doctors: boolean;
  } | null>(null);
  const [hasSearched, setHasSearched] = useState<boolean>(false);
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [selectedItemForCheckout, setSelectedItemForCheckout] = useState<Product | LabTest | null>(null);
  const [checkoutMessage, setCheckoutMessage] = useState<string>("");


  // backend path required when host the website on server  

  const PRODUCT_URL = "http://localhost:5000/api/products";
  const LAB_URL = "http://localhost:5000/api/health-products";
  const SOCKET_URL = "http://localhost:5000";

  // Fetch products
  const fetchProducts = async () => {
    try {
      const res = await axios.get(PRODUCT_URL);
      setProducts(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  // Fetch health products
  const fetchLabTests = async () => {
    try {
      const res = await axios.get(LAB_URL);
      const items = res.data.map((t: any) => ({ ...t, image: normalizeImage(t.image), createdAt: t.createdAt }));
      items.sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setLabTests(items);
    } catch (err) {
      console.error(err);
    }
  };

  // Search handler
  const handleSearch = () => {
    const query = searchQuery.toLowerCase().trim();
    if (!query) {
      setSearchResults(null);
      setHasSearched(false);
      return;
    }

    // Filter products by title or description
    const filteredProducts = products.filter(
      (p) =>
        p.title.toLowerCase().includes(query) ||
        (p.description && p.description.toLowerCase().includes(query))
    );

    // Filter lab tests by name or health concern
    const filteredLabTests = labTests.filter(
      (t) =>
        t.name.toLowerCase().includes(query) ||
        (t.healthConcern && t.healthConcern.toLowerCase().includes(query))
    );

    // Check if query matches doctor-related keywords
    const isDoctorQuery = ["doctor", "appointment", "consultant", "physician", "medical"].some(
      (keyword) => query.includes(keyword)
    );

    setSearchResults({
      products: filteredProducts,
      labTests: filteredLabTests,
      doctors: isDoctorQuery,
    });
    setHasSearched(true);
  };

  // Handle Enter key in search input
  const handleSearchInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  // Initial fetch & socket connection
  useEffect(() => {
    fetchProducts();
    fetchLabTests();

    const s = io(SOCKET_URL);
    setSocket(s);

    s.on("product-updated", () => fetchProducts());
    s.on("labtest-updated", () => fetchLabTests());

    return () => { s.disconnect(); };
  }, []);

  // Add item to cart
  const handleAddToCart = (item: Product | LabTest) => {
    // local cart preview
    const exists = cart.find((i) => i._id === item._id);
    if (exists) {
      setCart(cart.map((i) => (i._id === item._id ? { ...i, qty: i.qty + 1 } : i)));
    } else {
      setCart([...cart, { ...item, qty: 1 } as CartItem]);
    }

    // The context addToCart expects the product object (see app/context/cartContext.tsx)
    try {
      // If item is a Product-like object expected by context, pass minimal shape
      addToCart({ _id: item._id, title: (item as any).title || (item as any).name, amount: (item as any).amount || (item as any).price || 0 });
    } catch (e) {
      // fallback: ignore context errors
      console.error("addToCart context error:", e);
    }

    setShowPopup((item as any).title || (item as any).name);
    setTimeout(() => setShowPopup(null), 3000);
  };

  // Buy Now - Open Checkout Modal
  const handleBuyNow = (item: Product | LabTest) => {
    setSelectedItemForCheckout(item);
    setShowCheckoutModal(true);
  };

  // Handle Checkout Success
  const handleCheckoutSuccess = (message: string, order?: any) => {
    setCheckoutMessage(message);
    setShowCheckoutModal(false);
    setSelectedItemForCheckout(null);
    setTimeout(() => setCheckoutMessage(""), 5000);
    if (socket && order) socket.emit("new-order", order);
  };
  // type of medicens

  const phamnacyTypes = [
    { name: "Medicine", image: "/images/medicine.jpg" },
    { name: "Lab Test", image: "/images/blood-sample.jpg" },
    { name: "Doctor Appointment", image: "/images/doctor.png" },
    { name: "Health Products", image: "/images/heart.jpeg" },
  ];
  // Removed Typed.js usage as 'Typed' is not defined or imported.
  // If you want to use Typed.js, install it and initialize inside useEffect.

  // brands 
  const brands = [
    { name: "Cipla", logo: "/images/cipla.png" },
    { name: "Sun Pharma", logo: "/images/sunpharma.png" },
    { name: "Dr. Reddy's", logo: "/images/drreddys.png" },
    { name: "Lupin", logo: "/images/lupin.png" },
    { name: "Abbott", logo: "/images/abbott.png" },
    { name: "Dabur", logo: "/images/dabur.png" },
    { name: "Himalaya", logo: "/images/himalaya.png" },
    { name: "Baidyanath", logo: "/images/baidyanath.png" },
    { name: "Vicks", logo: "/images/vicks.png" },
    { name: "Dolo", logo: "/images/dolo1.png" },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section with Search */}
      <div className="bg-primary text-white py-12 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Your Health, Our Priority</h1>
          <p className="text-lg md:text-xl mb-8 opacity-90">Find medicines, health products, and book appointments with ease</p>
          
          {/* Search Bar */}
          <div className="max-w-2xl mx-auto">
            <div className="flex items-center bg-white rounded-full shadow-lg overflow-hidden">
              <input
                type="text"
                placeholder="Search for medicines and health products"
                className="flex-1 px-6 py-4 outline-none text-text text-lg"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={handleSearchInputKeyDown}
              />
              <button 
                className="px-8 py-4 bg-primary hover:bg-dark-green text-white font-semibold cursor-pointer transition"
                onClick={handleSearch}
              >
                Search
              </button>
            </div>
          </div>
          
          <div className="mt-6">
            <span className="text-sm opacity-75">Need a prescription? </span>
            <button className="text-secondary hover:text-white font-semibold underline">Upload Now</button>
          </div>
        </div>
      </div>

      {/* Search Results Section */}
      {hasSearched && searchResults && (
        <div className="max-w-7xl mx-auto px-6 py-8">
          <h2 className="text-3xl font-bold mb-8 text-text text-center">Search Results for "{searchQuery}"</h2>

          {/* Products Results */}
          {searchResults.products.length > 0 && (
            <div className="mb-12">
              <h3 className="text-2xl font-semibold mb-6 text-text">Medicines</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {searchResults.products.map((p) => (
                  <div key={p._id} className="bg-white rounded-xl shadow-md p-6 flex flex-col hover:shadow-lg transition-shadow">
                    <div className="relative mb-4">
                      {p.image ? (
                        <Image src={normalizeImage(p.image)!} alt={p.title} width={300} height={200} className="rounded-lg object-cover w-full h-48" />
                      ) : (
                        <Image src="/images/medicine.jpg" alt="placeholder" width={300} height={200} className="rounded-lg object-cover w-full h-48" />
                      )}
                      {p.discount && p.discount > 0 && (
                        <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded-full text-sm font-bold">
                          {p.discount}% OFF
                        </div>
                      )}
                    </div>
                    <h3 className="font-semibold text-lg mb-2 text-text">{p.title}</h3>
                    <p className="text-sm text-gray-600 flex-1 mb-3">{p.description}</p>
                    
                    <div className="mt-auto">
                      <RatingStars rating={p.rating || 0} reviewCount={p.reviews?.length || 0} size="sm" />
                      
                      <div className="flex items-center gap-2 mb-4 mt-2">
                        <p className="font-bold text-xl text-text">
                          ₹{p.discount && p.discount > 0 ? (p.amount! * (1 - p.discount / 100)).toFixed(2) : p.amount}
                        </p>
                        {p.discount && p.discount > 0 && (
                          <p className="text-sm text-gray-500 line-through">₹{p.amount}</p>
                        )}
                      </div>
                      
                      <div className="flex gap-3">
                        <button className="flex-1 bg-secondary hover:bg-blue-700 text-white py-2 rounded-lg font-medium transition" onClick={() => handleAddToCart(p)}>Add to Cart</button>
                        <button className="flex-1 bg-primary hover:bg-dark-green text-white py-2 rounded-lg font-medium transition" onClick={() => handleBuyNow(p)}>Buy Now</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Lab Tests Results */}
          {searchResults.labTests.length > 0 && (
            <div className="mb-12">
              <h3 className="text-2xl font-semibold mb-6 text-text">Health Products</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {searchResults.labTests.map((test) => (
                  <div key={test._id} className="bg-white rounded-xl shadow-md p-6 flex flex-col hover:shadow-lg transition-shadow">
                    <div className="relative mb-4">
                      {test.image ? (
                        <Image src={test.image} alt={test.name} width={300} height={200} className="rounded-lg object-cover w-full h-48" />
                      ) : (
                        <Image src="/images/blood-sample.jpg" alt="placeholder" width={300} height={200} className="rounded-lg object-cover w-full h-48" />
                      )}
                      {test.discount && test.discount > 0 && (
                        <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded-full text-sm font-bold">
                          {test.discount}% OFF
                        </div>
                      )}
                    </div>
                    <h3 className="font-semibold text-lg mb-2 text-text">{test.name}</h3>
                    <p className="text-sm text-gray-600 flex-1 mb-3">{test.healthConcern}</p>
                    
                    <div className="mt-auto">
                      <RatingStars rating={test.rating || 0} reviewCount={test.reviews?.length || 0} size="sm" />
                      
                      <div className="flex items-center gap-2 mb-4 mt-2">
                        <p className="font-bold text-xl text-text">
                          ₹{test.discount && test.discount > 0 ? (test.price * (1 - test.discount / 100)).toFixed(2) : test.price}
                        </p>
                        {test.discount && test.discount > 0 && (
                          <p className="text-sm text-gray-500 line-through">₹{test.price}</p>
                        )}
                      </div>
                      
                      <div className="flex gap-3">
                        <button className="flex-1 bg-secondary hover:bg-blue-700 text-white py-2 rounded-lg font-medium transition" onClick={() => handleAddToCart(test)}>Add to Cart</button>
                        <button className="flex-1 bg-primary hover:bg-dark-green text-white py-2 rounded-lg font-medium transition" onClick={() => handleBuyNow(test)}>Buy Now</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Doctor Appointments Link */}
          {searchResults.doctors && (
            <div className="text-center mb-12">
              <h3 className="text-2xl font-semibold mb-4 text-text">Looking for Doctor Appointments?</h3>
              <Link href="/doctors">
                <button className="bg-primary hover:bg-dark-green text-white px-8 py-4 rounded-lg font-semibold text-lg transition">
                  Book Doctor Appointment
                </button>
              </Link>
            </div>
          )}

          {/* No Results Message */}
          {searchResults.products.length === 0 && searchResults.labTests.length === 0 && !searchResults.doctors && (
            <div className="text-center py-12">
              <p className="text-xl text-gray-600">No results found for "{searchQuery}"</p>
              <p className="text-gray-500 mt-2">Try searching for different keywords</p>
            </div>
          )}
        </div>
      )}

      <div>
        <h1>Medicinal Solutions o </h1>
      </div>
        <h1 className="text-2xl font-bold mb-4 text-text">Brand and company for medicines</h1>
      <div className="">
        <div className="overflow-x-auto overflow-y-hidden scrollbar-hide">
          <div className="flex space-x-4 py-5 px-4 sm:px-2 md:px-3">
            {brands.slice(0, 6).map((brand, index) => (
              <div key={index} className="flex-shrink-0 w-24 h-24 bg-white rounded-xl shadow-md flex items-center justify-center p-4 hover:shadow-lg transition-shadow">
                <img src={brand.logo} alt={brand.name} className="w-16 h-16 object-contain" />
              </div>
            ))}
          </div>
        </div>
      </div>
        {/* Services */}
        <section className="py-12 px-6 bg-gray-50">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-2xl font-bold text-center mb-8 text-text">Our Services</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {phamnacyTypes.slice(0, 4).map((type, index) => {
                const isLab = type.name.toLowerCase().includes("lab");
                const isDoctor = type.name.toLowerCase().includes("doctor");
                const tile = (
                  <div className="bg-white rounded-xl shadow-md p-6 text-center hover:shadow-lg transition-shadow">
                    <h3 className="font-semibold text-text">{type.name}</h3>
                  </div>
                );

                if (isLab) return (
                  <Link href="/lab-tests" key={index} className="no-underline">
                    {tile}
                  </Link>
                );

                if (isDoctor) return (
                  <Link href="/doctors" key={index} className="no-underline">
                    {tile}
                  </Link>
                );

                return <div key={index}>{tile}</div>;
              })}
            </div>
          </div>
        </section>

<Homeslider />

        {/* Featured Products */}
        <section className="py-12 px-6">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl font-bold mb-8 text-text text-center">Featured Products</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {products.slice(0, 8).map((p) => (
                <div key={p._id} className="bg-white rounded-xl shadow-md p-6 flex flex-col hover:shadow-lg transition-shadow">
                  <div className="relative mb-4">
                    {p.image ? (
                      <Image src={normalizeImage(p.image)!} alt={p.title} width={300} height={200} className="rounded-lg object-cover w-full h-48" />
                    ) : (
                      <Image src="/images/medicine.jpg" alt="placeholder" width={300} height={200} className="rounded-lg object-cover w-full h-48" />
                    )}
                    {p.discount && p.discount > 0 && (
                      <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded-full text-sm font-bold">
                        {p.discount}% OFF
                      </div>
                    )}
                  </div>
                  <h3 className="font-semibold text-lg mb-2 text-text">{p.title}</h3>
                  <p className="text-sm text-gray-600 flex-1 mb-3">{p.description}</p>
                  
                  <div className="mt-auto">
                    <RatingStars rating={p.rating || 0} reviewCount={p.reviews?.length || 0} size="sm" />
                    
                    <div className="flex items-center gap-2 mb-4 mt-2">
                      <p className="font-bold text-xl text-text">
                        ₹{p.discount && p.discount > 0 ? (p.amount! * (1 - p.discount / 100)).toFixed(2) : p.amount}
                      </p>
                      {p.discount && p.discount > 0 && (
                        <p className="text-sm text-gray-500 line-through">₹{p.amount}</p>
                      )}
                    </div>
                    
                    <div className="flex gap-3">
                      <button className="flex-1 bg-secondary hover:bg-blue-700 text-white py-2 rounded-lg font-medium transition" onClick={() => handleAddToCart(p)}>Add to Cart</button>
                      <button className="flex-1 bg-primary hover:bg-dark-green text-white py-2 rounded-lg font-medium transition" onClick={() => handleBuyNow(p)}>Buy Now</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
        {/* Health Products */}
        <section className="py-12 px-6 bg-gray-50">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl font-bold mb-8 text-text text-center">Health Products</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {labTests.slice(0, 8).map((t) => (
            <div key={t._id} className="bg-white rounded-xl shadow-md p-6 flex flex-col hover:shadow-lg transition-shadow">
              <div className="relative mb-4">
                {t.image ? (
                  <Image src={t.image} alt={t.name} width={300} height={200} className="rounded-lg object-cover w-full h-48" />
                ) : (
                  <Image src="/images/heart.jpeg" alt="placeholder" width={300} height={200} className="rounded-lg object-cover w-full h-48" />
                )}
              </div>
              <h3 className="font-semibold text-lg mb-2 text-text">{t.name}</h3>
              <p className="text-sm text-gray-600 flex-1 mb-3">{t.healthConcern}</p>
              <div className="mt-auto">
                <div className="mb-4">
                  <p className="font-bold text-xl text-text">₹{t.price}</p>
                </div>
                <div className="flex gap-3">
                  <button className="flex-1 bg-secondary hover:bg-blue-700 text-white py-2 rounded-lg font-medium transition" onClick={() => handleAddToCart(t)}>Add to Cart</button>
                  <button className="flex-1 bg-primary hover:bg-dark-green text-white py-2 rounded-lg font-medium transition" onClick={() => handleBuyNow(t)}>Buy Now</button>
                </div>
              </div>
            </div>
              ))}
            </div>
          </div>
        </section>

      {/* Cart Preview */}
      {
        cart.length > 0 && (
          <div className="fixed bottom-4 right-4 bg-white shadow p-4 rounded-lg z-50">
            <h3 className="font-bold mb-2">Cart</h3>
            {cart.map((item) => (
              <div key={item._id} className="flex justify-between">
                <span>{(item as any).title || (item as any).name} x {item.qty}</span>
                <span>₹{(((item as any).amount || (item as any).price || 100) * item.qty)}</span>
              </div>
            ))}
            <div className="font-bold mt-2">
              Total: ₹{cart.reduce((sum, i) => sum + (((i as any).amount || (i as any).price || 100) * i.qty), 0)}
            </div>
          </div>
        )
      }

      {/* Pop-up Notification */}
      {
        showPopup && (
          <div className="fixed bottom-4 right-4 bg-green-500 text-white px-4 py-2 rounded shadow-lg z-50">
            {showPopup} added to cart!
          </div>
        )
      }

      {/* Checkout Success Message */}
      {
        checkoutMessage && (
          <div className="fixed bottom-4 right-4 bg-green-600 text-white px-6 py-3 rounded-lg shadow-lg z-50">
            {checkoutMessage}
          </div>
        )
      }

      {/* Checkout Modal */}
      {showCheckoutModal && selectedItemForCheckout && (
        <CheckoutModal
          item={selectedItemForCheckout}
          onClose={() => {
            setShowCheckoutModal(false);
            setSelectedItemForCheckout(null);
          }}
          onSuccess={handleCheckoutSuccess}
          normalizeImage={normalizeImage}
        />
      )}

    </div>
  

  );
}